function x = movex(prob, x, p)
%moving x left, right or stay put depend on the random output

if prob>1*p && prob<2*p
    if x~=5
    x=x+1; 
    end
    if x==5
    x1=x;
    x=x1;
    end 
end 
if prob>3*p && prob<4*p
    if x~=-5
    x=x-1;
    end 
    if x==-5 
    x1=x;
    x=x1;
    end 
end 
if prob>4*p 
    x1=x;
    x=x1;
end
end
