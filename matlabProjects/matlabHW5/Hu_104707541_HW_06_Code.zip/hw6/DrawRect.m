function DrawRect(a,b,L,W,c)
x = [a a+L a+L a a];
y = [b b b+W b+W b];
fill (x,y,c)
end 