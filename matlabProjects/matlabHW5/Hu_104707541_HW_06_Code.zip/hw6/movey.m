function y = movey(prob, y, p)

if prob<1*p
    if y~=5
    y=y+1; 
    end 
    if y==5
    y1=y;
    y=y1;
    end 
end 
if prob>2*p && prob<3*p
    if y~=-5
    y=y-1;
    end 
    if y==-5 
    y1=y;
    y=y1;
    end 
if prob>4*p 
    y1=y;
    y=y1;
end
end